#Unlike getfreqsfromtext.py, this script gets a vector of bits from frequencies derived *only* from the text you input, not from any external corpus

import sys,collections,contractions,string
import numpy as np


text = sys.stdin.read()

#PART I: cleaning
#first, clean the string: expand contractions, strip punctuation and capitalisation
s=contractions.fix(text)
cleaned=s.translate(str.maketrans('', '', string.punctuation)).lower()

words = cleaned.split()

wordcount = collections.Counter(words)

vector = []

for w in words:
    prob = float(wordcount[w]/len(words))
    bit = np.log2(1/prob)
    vector.append(bit)

for ii in vector:
    sys.stdout.write("%s\n" % ii)


