#Run Study on Pyccle, subdirectory by subdirectory

rm pyccle.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A0[12]*.xml.tag | python3 pyccleFreq.py > eebo1A01and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A0[34]*.xml.tag | python3 pyccleFreq.py > eebo1A03and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A0[56]*.xml.tag | python3 pyccleFreq.py > eebo1A05and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A0[789]*.xml.tag | python3 pyccleFreq.py > eebo1A07and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A1[12]*.xml.tag | python3 pyccleFreq.py > eebo1A11and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A1[34]*.xml.tag | python3 pyccleFreq.py > eebo1A13and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A1[56]*.xml.tag | python3 pyccleFreq.py > eebo1A15and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A1[789]*.xml.tag | python3 pyccleFreq.py > eebo1A17and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A2[12]*.xml.tag | python3 pyccleFreq.py > eebo1A21and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A2[34]*.xml.tag | python3 pyccleFreq.py > eebo1A23and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A2[56]*.xml.tag | python3 pyccleFreq.py > eebo1A25and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA0toA2/A2[789]*.xml.tag | python3 pyccleFreq.py > eebo1A27and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A3[12]*.xml.tag | python3 pyccleFreq.py > eebo1A31and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A3[34]*.xml.tag | python3 pyccleFreq.py > eebo1A33and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A3[56]*.xml.tag | python3 pyccleFreq.py > eebo1A35and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A3[789]*.xml.tag | python3 pyccleFreq.py > eebo1A37and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A4[12]*.xml.tag | python3 pyccleFreq.py > eebo1A41and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A4[34]*.xml.tag | python3 pyccleFreq.py > eebo1A43and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A4[56]*.xml.tag | python3 pyccleFreq.py > eebo1A45and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A4[789]*.xml.tag | python3 pyccleFreq.py > eebo1A47and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A5[12]*.xml.tag | python3 pyccleFreq.py > eebo1A51and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A5[34]*.xml.tag | python3 pyccleFreq.py > eebo1A53and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A5[56]*.xml.tag | python3 pyccleFreq.py > eebo1A55and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA3toA5/A5[789]*.xml.tag | python3 pyccleFreq.py > eebo1A57and8and9.bits.txt

echo "finished a1-5"

#phase 1 textsA6toA8

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A6[12]*.xml.tag | python3 pyccleFreq.py > eebo1A61and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A6[34]*.xml.tag | python3 pyccleFreq.py > eebo1A63and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A6[56]*.xml.tag | python3 pyccleFreq.py > eebo1A65and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A6[789]*.xml.tag | python3 pyccleFreq.py > eebo1A67and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A7[12]*.xml.tag | python3 pyccleFreq.py > eebo1A71and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A7[34]*.xml.tag | python3 pyccleFreq.py > eebo1A73and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A7[56]*.xml.tag | python3 pyccleFreq.py > eebo1A75and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A7[789]*.xml.tag | python3 pyccleFreq.py > eebo1A77and8and9.bits.txt



cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A8[12]*.xml.tag | python3 pyccleFreq.py > eebo1A81and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A8[34]*.xml.tag | python3 pyccleFreq.py > eebo1A83and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A8[56]*.xml.tag | python3 pyccleFreq.py > eebo1A85and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA6toA8/A8[789]*.xml.tag | python3 pyccleFreq.py > eebo1A87and8and9.bits.txt


#phase 1 textsA9toB

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/A9[12]*.xml.tag | python3 pyccleFreq.py > eebo1A91and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/A9[34]*.xml.tag | python3 pyccleFreq.py > eebo1A93and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/A9[56]*.xml.tag | python3 pyccleFreq.py > eebo1A95and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/A9[789]*.xml.tag | python3 pyccleFreq.py > eebo1A97and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/B0[12]*.xml.tag | python3 pyccleFreq.py > eebo1B1and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/B0[34]*.xml.tag | python3 pyccleFreq.py > eebo1B3and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/B0[56]*.xml.tag | python3 pyccleFreq.py > eebo1B5and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/B07*.xml.tag ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase1/texts/textsA9toB/B3*.xml.tag | python3 pyccleFreq.py > eebo1B7and3.bits.txt


echo "finished a6-B, starting phase 2"



##phase 2


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A0[12]*.xml.tag | python3 pyccleFreq.py > eebo2A01and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A0[34]*.xml.tag | python3 pyccleFreq.py > eebo2A03and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A0[56]*.xml.tag | python3 pyccleFreq.py > eebo2A05and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A0[789]*.xml.tag | python3 pyccleFreq.py > eebo2A07and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A1[12]*.xml.tag | python3 pyccleFreq.py > eebo2A11and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A1[34]*.xml.tag | python3 pyccleFreq.py > eebo2A13and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A1[56]*.xml.tag | python3 pyccleFreq.py > eebo2A15and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A1[789]*.xml.tag | python3 pyccleFreq.py > eebo2A17and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A2[12]*.xml.tag | python3 pyccleFreq.py > eebo2A21and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A2[34]*.xml.tag | python3 pyccleFreq.py > eebo2A23and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A2[56]*.xml.tag | python3 pyccleFreq.py > eebo2A25and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA0toA2/A2[789]*.xml.tag | python3 pyccleFreq.py > eebo2A27and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A3[12]*.xml.tag | python3 pyccleFreq.py > eebo2A31and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A3[34]*.xml.tag | python3 pyccleFreq.py > eebo2A33and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A3[56]*.xml.tag | python3 pyccleFreq.py > eebo2A35and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A3[789]*.xml.tag | python3 pyccleFreq.py > eebo2A37and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A4[12]*.xml.tag | python3 pyccleFreq.py > eebo2A41and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A4[34]*.xml.tag | python3 pyccleFreq.py > eebo2A43and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A4[56]*.xml.tag | python3 pyccleFreq.py > eebo2A45and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A4[789]*.xml.tag | python3 pyccleFreq.py > eebo2A47and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A5[12]*.xml.tag | python3 pyccleFreq.py > eebo2A51and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A5[34]*.xml.tag | python3 pyccleFreq.py > eebo2A53and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A5[56]*.xml.tag | python3 pyccleFreq.py > eebo2A55and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA3toA5/A5[789]*.xml.tag | python3 pyccleFreq.py > eebo2A57and8and9.bits.txt


echo "finished a1-5 phase2"

#phase 2 textsA6toA8

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A6[12]*.xml.tag | python3 pyccleFreq.py > eebo2A61and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A6[34]*.xml.tag | python3 pyccleFreq.py > eebo2A63and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A6[56]*.xml.tag | python3 pyccleFreq.py > eebo2A65and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A6[789]*.xml.tag | python3 pyccleFreq.py > eebo2A67and8and9.bits.txt


cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A7[12]*.xml.tag | python3 pyccleFreq.py > eebo2A71and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A7[34]*.xml.tag | python3 pyccleFreq.py > eebo2A73and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A7[56]*.xml.tag | python3 pyccleFreq.py > eebo2A75and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A7[789]*.xml.tag | python3 pyccleFreq.py > eebo2A77and8and9.bits.txt



cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A8[12]*.xml.tag | python3 pyccleFreq.py > eebo2A81and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A8[34]*.xml.tag | python3 pyccleFreq.py > eebo2A83and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A8[56]*.xml.tag | python3 pyccleFreq.py > eebo2A85and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA6toA8/A8[789]*.xml.tag | python3 pyccleFreq.py > eebo2A87and8and9.bits.txt


#phase 2 textsA9toB

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/A9[12]*.xml.tag | python3 pyccleFreq.py > eebo2A91and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/A9[34]*.xml.tag | python3 pyccleFreq.py > eebo2A93and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/A9[56]*.xml.tag | python3 pyccleFreq.py > eebo2A95and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/A9[789]*.xml.tag | python3 pyccleFreq.py > eebo2A97and8and9.bits.txt

echo "finished a6-9 phase2"

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/B0[12]*.xml.tag | python3 pyccleFreq.py > eebo2B1and2.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/B0[34]*.xml.tag | python3 pyccleFreq.py > eebo2B3and4.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/B0[56]*.xml.tag | python3 pyccleFreq.py > eebo2B5and6.bits.txt

cat ~/CurrentLx/OldNorse/gentdigs/pyccle-eebo-phase2/texts/textsA9toB/B[123]*.xml.tag | python3 pyccleFreq.py > eebo2B123.bits.txt

echo "finished b phase2"

cat ecco.bits.txt eebo*.bits.txt > pyccle-all.bits.txt

rm eebo*.bits.txt
