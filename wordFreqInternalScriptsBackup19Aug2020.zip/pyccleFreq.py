#This splits pyccle data into sentences and then gets bits for each sentence separately.

#Like mobyFreq.py, but unlike getfreqsfromtext.py, this script gets a vector of bits from frequencies derived *only* from the text you input, not from any external corpus

import sys,collections,contractions,string
import numpy as np


lines = sys.stdin.readlines()

intermed = open("pyccle.txt","w")

for line in lines:
    fields = line.split("\t")
    intermed.write("%s " % fields[0])

intermed.close()


lines = open("pyccle.txt","r").readlines()
text = open("pyccle.txt","r").read()


#PART I: cleaning
#first, clean the string: expand contractions, strip punctuation and capitalisation
s=contractions.fix(text)
cleaned=s.translate(str.maketrans('', '', string.punctuation)).lower()
words = cleaned.split()

wordcount = collections.Counter(words)


for l in lines:
    #PART I: cleaning
    #first, clean the string: expand contractions, strip punctuation and capitalisation
    s=contractions.fix(l)
    cleaned=s.translate(str.maketrans('', '', string.punctuation)).lower()
    linewords = cleaned.split()

    ii = 0
    while ii < len(linewords):
        prob = float(wordcount[linewords[ii]]/len(words))
        bit = np.log2(1/prob)
        if ii == (len(linewords)-1):
            sys.stdout.write("%s\n" % (bit))
        else:
            sys.stdout.write("%s," % (bit))
        ii=ii+1
