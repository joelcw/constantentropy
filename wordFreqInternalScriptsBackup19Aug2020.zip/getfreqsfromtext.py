from dormouse import dorm,uido,getDORM,infovec
import sys
from nltk.tokenize import sent_tokenize
import nltk
#nltk.download('punkt')
#text to sentence packages

text = sys.stdin.read()

vector = infovec(text)

for ii in vector:
    sys.stdout.write("%s\n" % ii)




    
####begin debug
#import string,contractions

#s=contractions.fix(text)
#s=s.translate(str.maketrans('', '', string.punctuation)).lower()
#s=s.split()

#ii = 0

#while ii < 4:
#    sys.stdout.write("%s %s\n" % (s[ii],vector[ii]))
#    ii=ii+1

####end debug
